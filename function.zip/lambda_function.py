def lambda_handler(event, context):
    return "Hello again from Lambda!"
